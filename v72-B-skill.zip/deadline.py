"""Deadline scheduling of required targets (v7.1, S2).

A required target counts when one exposure reaches the completion factor g_req (scoring.required.
observed_factor_threshold; not fixed at 0.5). Only the best exposure counts, so a target needs one exposure
long enough under a good enough sky before it sets for the season. This module ranks the open required
targets by laxity (least slack first) and gives the planner a priority multiplier per target:

  T_need(i)   = g_req * f0*T0 / (flux_i * Qhat_i)                      no usable exposure yet
              = T_prev * (g_req / g_i) * (model_prev / model_typical)   after a try that reached g_i < g_req
  n_eff(i)    = nights left in its season window * share of nights that turn out usable (learned)
  backlog(i)  = open required targets in its RA region that set no later than it (EDF rank) / C
                where C = required completions a region gets per usable night (learned rate x hours)
  slack(i)    = n_eff(i) - backlog(i) - T_need(i) / usable seconds per night
  pressure(i) = 1 / (1 + max(0, slack(i)) / SLACK_SCALE)            1 when late, -> 0 with much slack
  priority(i) = 1 + K * pressure(i) * need(i),   need(i) = clip(1 - g_i / g_req, NEED_FLOOR, 1)

The planner multiplies the required bonus by priority(i), and keeps its "wait for a better sky" discounts only
while slack(i) > DEFER_SLACK. Public catalogue, night calendar and own results only; standard library only.
"""
from __future__ import annotations

import math
import os


def _env(name, default):
    return type(default)(os.environ.get(f"V7_{name}", default))


ENABLED = _env("DEADLINE", 0)
K = _env("DL_K", 1.0)                    # extra bonus share at full pressure
SLACK_SCALE = _env("DL_SLACK_SCALE", 3.0)  # nights of slack at which pressure is 1/2
DEFER_SLACK = _env("DL_DEFER_SLACK", 4.0)  # keep timing/forecast deferral only above this slack (nights)
NEED_FLOOR = _env("DL_NEED_FLOOR", 0.5)  # a nearly done target still risks the whole penalty
REGION_DEG = _env("DL_REGION_DEG", 30.0)
REGION_HOURS = _env("DL_REGION_HOURS", 2.0)   # hours a region is well placed in a night
PRIOR_CLEAR = 0.5
PRIOR_PER_FIELD = 1.5                    # required targets completed per exposure (prior)
Q_TYPICAL = 0.6


class DeadlineScheduler:
    def __init__(self, planner):
        self.p = planner
        self.g_req = planner.g_req
        n = len(planner.ids)
        self.req = [i for i in range(n) if planner.required[i] and planner.hmax[i] > 0.0]
        self.pressure = {}
        self.slack = {}
        self.t_need = {}
        self.tries = {}                  # i -> (T, model, g) of the best try below g_req
        self.useful_nights = set()
        self.done_nights = {}            # night -> required completions
        self.obs_seconds = 0.0
        self.completions = 0
        self.night = -1
        self.night_len = [max(1.0, (end - start).total_seconds()) for start, end in planner.nights]
        self.summary = ""

    # --- learning -----------------------------------------------------------------------------------------
    def on_exposure(self, night, duration, any_positive):
        if any_positive and night is not None:
            self.useful_nights.add(night)
            self.obs_seconds += duration

    def on_required(self, i, T, model, g_before, g_after):
        if g_after >= self.g_req > g_before:
            self.completions += 1
        elif g_after < self.g_req and g_after > 0.0:
            old = self.tries.get(i)
            if old is None or g_after > old[2]:
                self.tries[i] = (T, model, g_after)

    def clear_rate(self, night_index):
        past = max(0, night_index)
        return (len(self.useful_nights) + 2.0 * PRIOR_CLEAR) / (past + 2.0)

    def need_seconds(self, i, model=None):
        """Exposure that should lift target i to g_req (formula of the current g, see the module doc)."""
        p = self.p
        typical = model if model else p.ideal_model[i] * 0.85
        q = (p.good_scale or p.prior_scale or Q_TYPICAL)
        try_ = self.tries.get(i)
        if try_ is not None and try_[2] > 0.0:
            T, m, g = try_
            return T * (self.g_req / g) * (m / max(typical, 1e-6))
        return self.g_req * p.f0t0 / (max(p.flux[i], 1e-4) * max(typical, 1e-6) * max(q, 0.05))

    # --- the per-night plan -------------------------------------------------------------------------------
    def update(self, night_index):
        if night_index == self.night:
            return
        self.night = night_index
        p = self.p
        clear = self.clear_rate(night_index)
        open_ = [i for i in self.req if p.factor[i] < self.g_req and p.last_night[i] >= night_index]
        t_need = {i: self.need_seconds(i) for i in open_}
        # required completions per observing hour: learned, with a geometric prior
        med = sorted(t_need.values())[len(t_need) // 2] if t_need else 1800.0
        prior_rate = PRIOR_PER_FIELD * 3600.0 / max(600.0, min(p.max_exposure, med))
        hours = self.obs_seconds / 3600.0
        rate = (self.completions + prior_rate * 20.0) / (hours + 20.0)
        cap = max(1.0, rate * REGION_HOURS)
        regions: dict = {}
        for i in open_:
            regions.setdefault(int(p.ra[i] // REGION_DEG), []).append(i)
        night_s = sum(self.night_len[night_index:night_index + 10]) / max(1, len(self.night_len[night_index:night_index + 10]))
        self.pressure, self.slack, self.t_need = {}, {}, t_need
        tight = 0
        for members in regions.values():
            members.sort(key=lambda i: (p.last_night[i], t_need[i]))
            for rank, i in enumerate(members, 1):
                left = p.last_night[i] - max(night_index, p.first_night[i]) + 1
                n_eff = max(0.0, left) * clear
                slack = n_eff - rank / cap - min(t_need[i], p.max_exposure) / (night_s * clear + 1.0)
                self.slack[i] = slack
                self.pressure[i] = 1.0 / (1.0 + max(0.0, slack) / SLACK_SCALE)
                tight += slack <= 0.0
        self.summary = (f"deadline: night {night_index} open {len(open_)} tight {tight} clear {clear:.2f} "
                        f"rate {rate:.2f}/h cap/region {cap:.1f}")
        if night_index % 10 == 0:
            p.log(self.summary)
        p.vdirty.update(open_)

    def priority(self, i):
        """Bonus multiplier of an open required target (see the module doc)."""
        f = self.p.factor[i]
        need = min(1.0, max(NEED_FLOOR, 1.0 - f / self.g_req))
        return 1.0 + K * self.pressure.get(i, 0.0) * need

    def may_defer(self, i):
        """Keep the 'better moment later' discounts only for targets with real slack."""
        return self.slack.get(i, 1e9) > DEFER_SLACK
