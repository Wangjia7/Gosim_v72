"""Season strategist (v7.2, layer 3): a slow control loop over the greedy planner's two time knobs.

Every REVIEW_NIGHTS nights it looks at the realized best-score gain per observing hour by exposure-duration bucket
(the number the leaderboard pays for, not the planner's prediction) and chooses, from a small menu, the exposure cap
and the time-price share the planner uses next. Long exposures taken in poor sky were the largest measured loss on
the public cards (3600 s exposures earned a third of what 600-900 s exposures earned per hour); on a time-rich card
the same cap would cost depth, so the choice is made per card from its own data instead of being fixed.

Two deciders share the same menu and the same evidence:
  rules  - one step per review: raise the time price (or cap) while the longest allowed bucket earns much less per
           hour than the best shorter bucket; relax it again when it earns nearly as much (the price never forbids a
           long exposure, so the data keep coming even while it is high).
  model  - optional (V7_STRATEGIST=model): the same table is sent to the LLM through the existing asynchronous
           client; its answer is schema-checked, limited to one step from the current setting, and applied when it
           arrives. If it is late, invalid or unavailable, the rules' choice stands. The model never sees or sets
           anything outside the menu.

Switches: V7_STRATEGIST=off|rules|model (default off), V7_STRAT_NIGHTS (review period, default 5),
V7_STRAT_WINDOW (nights of evidence, default 12), V7_STRAT_MIN_H (hours per bucket before it counts, default 3),
V7_STRAT_SCARCITY_MIN (planner time scarcity below which the strategist stays off, default 0.4).
"""
import json
import os

MODE = os.environ.get("V7_STRATEGIST", "off")
REVIEW_NIGHTS = int(os.environ.get("V7_STRAT_NIGHTS", "5"))
WINDOW = int(os.environ.get("V7_STRAT_WINDOW", "12"))
MIN_HOURS = float(os.environ.get("V7_STRAT_MIN_H", "3"))
SCARCITY_MIN = float(os.environ.get("V7_STRAT_SCARCITY_MIN", "0.4"))   # time-rich seasons (old card d: 0.05) are left alone
WAIT_SECONDS = 8.0

MENU_MAX_T = (1800, 2400, 3600)
MENU_LAMBDA = (1.0,)                     # x LAMBDA_FRAC; a higher time price lost on every old card (lam60: -93..-477),
                                         # so the menu holds only the tuned value until a card shows otherwise
BUCKETS = ((0, 900), (1200, 1800), (2400, 2400), (3000, 3600))
RAISE_BELOW = 0.5                         # top bucket earns < this share of the best shorter bucket: price time up
RELAX_ABOVE = 0.8                         # ... >= this share: price it down again
CAP_BELOW = 0.35                          # and when it is this bad for the whole window, also cap the duration

SYSTEM = ("You are the season strategist of a robotic spectroscopic survey. The planner chooses fields greedily each "
          "step; you only set two slow knobs for the next few nights: the exposure cap and the time-price level. "
          "Evidence: realized leaderboard gain per observing hour by exposure-duration bucket (recent window and whole "
          "season), hours spent, time left. Long exposures in poor sky earn little; on a time-rich survey with faint "
          "targets a cap costs depth. Move at most one step from the current setting. Reply with one JSON object only: "
          '{"max_t": 1800|2400|3600, "lambda_level": 0, "reason": "<=120 chars"}.')


def bucket_of(duration):
    for k, (lo, hi) in enumerate(BUCKETS):
        if lo <= duration <= hi:
            return k
    return len(BUCKETS) - 1 if duration > BUCKETS[-1][1] else 0


class Strategist:
    def __init__(self, planner, client, log=lambda text: None):
        self.planner = planner
        self.client = client if MODE == "model" else None
        self.log = log
        self.rows = []                      # (night_index, duration, gain)
        self.max_t_level = MENU_MAX_T.index(min(MENU_MAX_T, key=lambda t: abs(t - planner.max_t)))
        self.lambda_level = 0
        # with telescope time to spare the alternative to a long exposure is idling: the knobs stay put
        self.enabled = getattr(planner, "scarcity", 1.0) >= SCARCITY_MIN
        if not self.enabled:
            log(f"v7 strategist off: time scarcity {getattr(planner, 'scarcity', 0.0):.2f} < {SCARCITY_MIN}")
        self.last_review = -1
        self.call = None
        self.reviews = 0
        self.changes = 0

    # -- evidence ------------------------------------------------------------------------------------------
    def on_exposure(self, night_index, duration, gain):
        self.rows.append((night_index, int(duration), max(0.0, float(gain))))

    def table(self, night_index):
        recent = [[0.0, 0.0] for _ in BUCKETS]
        season = [[0.0, 0.0] for _ in BUCKETS]
        for night, duration, gain in self.rows:
            k = bucket_of(duration)
            season[k][0] += duration / 3600.0
            season[k][1] += gain
            if night_index - night < WINDOW:
                recent[k][0] += duration / 3600.0
                recent[k][1] += gain
        rate = lambda cell: (cell[1] / cell[0]) if cell[0] >= MIN_HOURS - 1e-9 else None
        return {"recent": [{"bucket": f"{lo}-{hi}s", "hours": round(c[0], 1), "gain": round(c[1]), "gain_per_hour": None if rate(c) is None else round(rate(c), 1)}
                           for (lo, hi), c in zip(BUCKETS, recent)],
                "season": [{"bucket": f"{lo}-{hi}s", "hours": round(c[0], 1), "gain": round(c[1]), "gain_per_hour": None if rate(c) is None else round(rate(c), 1)}
                           for (lo, hi), c in zip(BUCKETS, season)]}

    # -- deciders ------------------------------------------------------------------------------------------
    def rules_choice(self, table):
        """One step from the current setting, from the recent window (season confirms the cap)."""
        allowed = [row for row in table["recent"] if int(row["bucket"].split("-")[0]) <= MENU_MAX_T[self.max_t_level]]
        rated = [row for row in allowed if row["gain_per_hour"] is not None]
        max_t, lam = self.max_t_level, self.lambda_level
        if len(rated) >= 2:
            top = rated[-1]
            best_shorter = max(row["gain_per_hour"] for row in rated[:-1])
            if best_shorter > 0:
                share = top["gain_per_hour"] / best_shorter
                if share < RAISE_BELOW:
                    if lam < len(MENU_LAMBDA) - 1:
                        lam += 1
                    elif max_t > 0:
                        season_top = next((r for r in table["season"] if r["bucket"] == top["bucket"]), None)
                        season_best = max([r["gain_per_hour"] for r in table["season"] if r["gain_per_hour"] is not None and r is not season_top] or [0])
                        if season_top and season_top["gain_per_hour"] is not None and season_best > 0 and season_top["gain_per_hour"] / season_best < CAP_BELOW:
                            max_t -= 1
                elif share >= RELAX_ABOVE:
                    if max_t < len(MENU_MAX_T) - 1:
                        max_t += 1
                    elif lam > 0:
                        lam -= 1
        return max_t, lam

    def clamp(self, max_t, lam):
        max_t = min(max(max_t, self.max_t_level - 1), self.max_t_level + 1)
        lam = min(max(lam, self.lambda_level - 1), self.lambda_level + 1)
        return min(max(max_t, 0), len(MENU_MAX_T) - 1), min(max(lam, 0), len(MENU_LAMBDA) - 1)

    def model_choice(self, answer):
        if not isinstance(answer, dict):
            return None
        try:
            max_t = MENU_MAX_T.index(int(answer["max_t"]))
            lam = int(answer["lambda_level"])
            if not 0 <= lam < len(MENU_LAMBDA):
                return None
        except (KeyError, ValueError, TypeError):
            return None
        return self.clamp(max_t, lam), str(answer.get("reason", ""))[:120]

    # -- control -------------------------------------------------------------------------------------------
    def update(self, night_index, hours, wallclock_left):
        """Called once per decision; cheap unless a review is due or a model answer arrived."""
        if self.call is not None and self.call.done():
            choice = self.model_choice(self.client.collect(self.call))
            self.call = None
            if choice is not None:
                self.apply(*choice[0], source="model", reason=choice[1])
        if not self.enabled or night_index - self.last_review < REVIEW_NIGHTS or len(self.rows) < 30:
            return
        self.last_review = night_index
        self.reviews += 1
        table = self.table(night_index)
        max_t, lam = self.rules_choice(table)
        self.apply(max_t, lam, source="rules", reason="realized gain per hour by duration bucket")
        if self.client is not None and self.call is None:
            payload = {"night": night_index, "current": {"max_t": MENU_MAX_T[self.max_t_level], "lambda_level": self.lambda_level},
                       "menu": {"max_t": list(MENU_MAX_T), "lambda_level": list(range(len(MENU_LAMBDA)))},
                       "nights_left": max(0, len(self.planner.nights) - night_index - 1), "evidence": table}
            self.call = self.client.submit("strategist", SYSTEM, payload, wallclock_left)
            if self.call is not None:
                self.call.wait_limit = WAIT_SECONDS

    def apply(self, max_t, lam, source, reason=""):
        changed = (max_t, lam) != (self.max_t_level, self.lambda_level)
        self.max_t_level, self.lambda_level = max_t, lam
        self.planner.max_t = MENU_MAX_T[max_t]
        self.planner.lambda_scale = MENU_LAMBDA[lam]
        if changed:
            self.changes += 1
        self.log("v7 strategist " + json.dumps({"source": source, "max_t": self.planner.max_t, "lambda_scale": self.planner.lambda_scale,
                                               "changed": changed, "reason": reason}, ensure_ascii=False, separators=(",", ":")))

    def summary(self):
        return {"reviews": self.reviews, "changes": self.changes, "max_t": MENU_MAX_T[self.max_t_level], "lambda_level": self.lambda_level}
