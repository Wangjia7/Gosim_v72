"""Sky map (v7.1, V7_SKYMAP): how much a directional weather notice lowers the sky, learned from our own hits.

A bulletin notice says which sector is affected and when; it does not say how wide, how high or how strong. The planner
used one fixed rule for all of them (+-67.5 deg azimuth below 75 deg altitude, value x 0.35).

Signal: every unsaturated positive hit gives a quality ratio r (planner.on_result). Dividing by the median r of
directions far from any directional notice within +-WINDOW hours, rho = r / baseline, removes the instrument efficiency
and the all-sky weather and leaves the directional loss. A hit is
  affected  within AZ_EDGES[-1] deg azimuth of a directional notice's sector centre (binned by that distance and altitude)
  baseline  more than CLEAN_DEG from every directional notice
and is resolved RESOLVE hours later, once the baseline around it is known (fewer than MIN_BASE baseline hits: dropped).
Per event kind and bin: log rho_hat = (sum log rho + SHRINK * log prior) / (n + SHRINK), clipped to [FLOOR, 1].
The prior is the continuous rule 1 - (1 - PRIOR_C) * share of the bin below PRIOR_H altitude and within PRIOR_W deg.

Modes (V7_SKYMAP):
  off     the old fixed rule
  shadow  learn and log only, decisions unchanged (the estimator can be checked against a synthetic card's truth)
  narrow  the prior geometry instead of the old rule, no learning
  learn   the learned bins; a bin with fewer than EXPLORE_N samples is read optimistically
          (1 - (1 - rho_hat) * EXPLORE) while exposures that touch such bins stay within BUDGET of all exposures
V7_SKYMAP_NS=1 also hands the factor per slot to the night plan (nightsched), with tonight's notices held fixed.
Blocking kinds (rocket launch), closing kinds (rain, storm) and terrain keep the old rule. Public bulletins and own results only; standard library only.
"""
from __future__ import annotations

import json
import math
import os
from collections import deque


def _env(name, default):
    return type(default)(os.environ.get(f"V7_{name}", default))


MODE = os.environ.get("V7_SKYMAP", "off")
ACTIVE = MODE in ("narrow", "learn")
LEARN = MODE in ("shadow", "learn")
NS = _env("SKYMAP_NS", 0)
PRIOR_C = _env("SKYMAP_C", 0.65)
PRIOR_W = _env("SKYMAP_W", 50.0)
PRIOR_H = _env("SKYMAP_H", 65.0)
SHRINK = _env("SKYMAP_SHRINK", 5.0)
FLOOR = _env("SKYMAP_FLOOR", 0.3)
EXPLORE_N = _env("SKYMAP_EXPLORE_N", 5)
EXPLORE = _env("SKYMAP_EXPLORE", 0.5)
BUDGET = _env("SKYMAP_BUDGET", 0.05)
WINDOW = 2.0                                  # hours either side for the baseline
RESOLVE = 1.0                                 # hours after a hit before it is resolved
MIN_BASE = 3
CLEAN_DEG = 100.0
AZ_EDGES = (20.0, 40.0, 60.0, 75.0, 90.0)     # azimuth distance from the sector centre
ALT_EDGES = (45.0, 60.0, 75.0, 90.0)          # altitude (the first bin starts at the planner's limit)
DUMP = os.environ.get("V7_SKYMAP_DUMP", "")   # development only: one JSON line per resolved hit
DIRECTION_AZ = {"N": 0.0, "NE": 45.0, "E": 90.0, "SE": 135.0, "S": 180.0, "SW": 225.0, "W": 270.0, "NW": 315.0}
SKIP_KINDS = {"terrain_obstruction", "rocket_launch", "earthquake", "rain", "storm"}   # blocking, neutral or closing


def _bin(value, edges):
    for k, edge in enumerate(edges):
        if value < edge:
            return k
    return len(edges) - 1


def _overlap(lo, hi, top):
    return max(0.0, min(hi, top) - lo) / (hi - lo)


class SkyMap:
    def __init__(self, min_alt, log):
        self.min_alt = min_alt
        self.log = log
        self.base = deque()                   # (hours, r) far from any directional notice
        self.waiting = deque()                # (hours, alt, az, r, kind, direction, distance)
        self.bins = {}                        # (kind, az bin, alt bin) -> [n, sum log rho]
        self.exposures = 0
        self.explored = 0
        self.resolved = 0
        self.dropped = 0
        alt_lo = (min_alt,) + ALT_EDGES[:-1]
        az_lo = (0.0,) + AZ_EDGES[:-1]
        self.prior = {(a, h): 1.0 - (1.0 - PRIOR_C) * _overlap(az_lo[a], AZ_EDGES[a], PRIOR_W)
                      * _overlap(alt_lo[h], ALT_EDGES[h], PRIOR_H)
                      for a in range(len(AZ_EDGES)) for h in range(len(ALT_EDGES))}

    # --- geometry ----------------------------------------------------------------------------------------
    @staticmethod
    def sectors(notices):
        """Directional notices that scale the sky: [(kind, direction, centre azimuth)]."""
        return [(k, d, DIRECTION_AZ[d]) for k, d in notices if d in DIRECTION_AZ and k not in SKIP_KINDS]

    @staticmethod
    def _distance(az, centre):
        d = abs(az - centre) % 360.0
        return 360.0 - d if d > 180.0 else d

    def _estimate(self, kind, a, h):
        n, s = self.bins.get((kind, a, h), (0, 0.0))
        rho = math.exp((s + SHRINK * math.log(self.prior[(a, h)])) / (n + SHRINK))
        return min(1.0, max(FLOOR, rho)), n

    def factor(self, alt, az, sectors, explore=True):
        """Sky factor at (alt, az) under these sectors (1 = unaffected)."""
        out = 1.0
        for kind, _, centre in sectors:
            dist = self._distance(az, centre)
            if MODE == "narrow" or not LEARN:
                f = 1.0 - (1.0 - PRIOR_C) if dist <= PRIOR_W and alt < PRIOR_H else 1.0
            else:
                if dist >= AZ_EDGES[-1]:
                    continue
                f, n = self._estimate(kind, _bin(dist, AZ_EDGES), _bin(alt, ALT_EDGES))
                if explore and n < EXPLORE_N and self.explored <= BUDGET * max(20, self.exposures):
                    f = 1.0 - (1.0 - f) * EXPLORE
            out = min(out, f)
        return out

    # --- learning ----------------------------------------------------------------------------------------
    def on_exposure(self, hours, rows, notices):
        """rows: (alt, az, r) of the unsaturated positive hits of the exposure that just ended."""
        if not LEARN:
            return
        sectors = self.sectors(notices)
        self.exposures += 1
        touched = False
        for alt, az, r in rows:
            if r <= 0.0:
                continue
            near = min(((self._distance(az, c), k, d) for k, d, c in sectors), default=None)
            if near is None or near[0] > CLEAN_DEG:
                self.base.append((hours, r))
            elif near[0] < AZ_EDGES[-1]:
                dist, kind, direction = near
                self.waiting.append((hours, alt, az, r, kind, direction, dist))
                n = self.bins.get((kind, _bin(dist, AZ_EDGES), _bin(alt, ALT_EDGES)), (0, 0.0))[0]
                touched = touched or n < EXPLORE_N
        self.explored += touched
        self._resolve(hours)

    def _resolve(self, hours):
        while self.base and self.base[0][0] < hours - 2.0 * WINDOW - RESOLVE:
            self.base.popleft()
        while self.waiting and self.waiting[0][0] <= hours - RESOLVE:
            t, alt, az, r, kind, direction, dist = self.waiting.popleft()
            around = sorted(x for when, x in self.base if t - WINDOW <= when <= t + WINDOW)
            if len(around) < MIN_BASE:
                self.dropped += 1
                continue
            rho = min(3.0, max(0.05, r / around[len(around) // 2]))
            key = (kind, _bin(dist, AZ_EDGES), _bin(alt, ALT_EDGES))
            cell = self.bins.setdefault(key, [0, 0.0])
            cell[0] += 1
            cell[1] += math.log(rho)
            self.resolved += 1
            if DUMP:
                with open(DUMP, "a", encoding="utf-8") as out:
                    out.write(json.dumps({"h": round(t, 4), "alt": round(alt, 2), "az": round(az, 2), "kind": kind,
                                          "dir": direction, "dist": round(dist, 1), "rho": round(rho, 4),
                                          "nbase": len(around)}, separators=(",", ":")) + "\n")

    def summary(self):
        """Learned table per kind: rows = azimuth bins, columns = altitude bins, value (n)."""
        kinds = sorted({k for k, _, _ in self.bins})
        parts = []
        for kind in kinds:
            rows = []
            for a in range(len(AZ_EDGES)):
                cells = []
                for h in range(len(ALT_EDGES)):
                    f, n = self._estimate(kind, a, h)
                    cells.append(f"{f:.2f}({n})")
                rows.append(f"<{AZ_EDGES[a]:.0f}:" + " ".join(cells))
            parts.append(f"{kind} [" + " | ".join(rows) + "]")
        return (f"skymap {MODE}: resolved {self.resolved} dropped {self.dropped} explored {self.explored}/{self.exposures} "
                + "; ".join(parts))
