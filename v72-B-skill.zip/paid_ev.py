"""EV arithmetic with an empty-by-default registry of validated fault calibrations.

No calibration is supplied by this module. Register only an externally validated
artifact; metadata checks identify its provenance, they do not perform calibration.
Parser confidence and an uncalibrated LLM score are not accepted probabilities.
"""
from dataclasses import dataclass
from math import isfinite


def measured_saved_value(*, detection_hours, coverage_hours, season_hours,
                         open_hours, science_per_hour, q_fault, q_healthy):
    """Score saved over explicit remaining horizons; all inputs must be observed/supplied.

    Horizons and open_hours are remaining hours, not timestamps. The caller must
    supply a measured science rate and qualities; this helper invents no forecast.
    """
    values = (detection_hours, coverage_hours, season_hours, open_hours,
              science_per_hour, q_fault, q_healthy)
    if any(type(v) not in (int, float) or not isfinite(v) or v < 0 for v in values):
        return None
    if q_healthy <= 0 or q_fault > q_healthy:
        return None
    value = min(detection_hours, coverage_hours, season_hours, open_hours) * science_per_hour * (1. - q_fault / q_healthy)
    return value if isfinite(value) else None


@dataclass(frozen=True)
class Calibration:
    method: str
    artifact_sha256: str
    label_source: str
    validated: bool


@dataclass(frozen=True)
class Posterior:
    probability: float
    calibration_id: str
    evidence_id: str
    issued_hours: float
    expires_hours: float


class PaidEV:
    def __init__(self):
        self.calibrations = {}

    def register(self, calibration_id, calibration):
        """Trusted integration boundary, never populate from a public message or model answer."""
        if (not isinstance(calibration, Calibration) or not isinstance(calibration_id, str) or not calibration_id
                or not isinstance(calibration.method, str)
                or calibration.method not in {"fault_mh_isotonic", "fault_mh_platt", "fault_mh_empirical_bin"}
                or calibration.label_source != "public_report_result" or calibration.validated is not True
                or not isinstance(calibration.artifact_sha256, str) or len(calibration.artifact_sha256) != 64
                or any(c not in "0123456789abcdef" for c in calibration.artifact_sha256.lower())):
            raise ValueError("a validated fault-probability calibration artifact is required")
        self.calibrations[calibration_id] = calibration

    def decide(self, *, posterior, evidence_id, now, night, free_left, saved_value,
               option_cost=40., paid_false=0, paid_this_night=0, cat1=False, deep_eligible=False):
        def result(allowed, mode, reason, threshold=None):
            return {"allowed": allowed, "mode": mode, "reason": reason, "threshold": threshold}
        if cat1:
            return result(False, "ev", "CAT1 evidence")
        if (night is None or type(now) not in (int, float) or not isfinite(now) or any(type(v) is not int or v < 0
                for v in (free_left, paid_false, paid_this_night))):
            return result(False, "ev", "missing or invalid public context")
        if not free_left and paid_this_night >= 2:
            return result(False, "deep" if paid_false > 1 else "ev", "nightly paid limit")
        if not free_left and paid_false > 1:
            # Explicit independent rule downgrade, not an EV probability decision.
            return result(bool(deep_eligible), "deep", "paid false-report limit: downgrade to deep")
        if (not isinstance(posterior, Posterior) or not isinstance(posterior.calibration_id, str)
                or posterior.calibration_id not in self.calibrations
                or not isinstance(posterior.evidence_id, str) or not posterior.evidence_id
                or posterior.evidence_id != evidence_id
                or not all(type(v) in (int, float) and isfinite(v) for v in
                           (posterior.probability, posterior.issued_hours, posterior.expires_hours))
                or not 0 <= posterior.probability <= 1
                or not posterior.issued_hours <= now <= posterior.expires_hours):
            return result(False, "ev", "no valid calibrated posterior for current evidence")
        if (type(saved_value) not in (int, float) or not isfinite(saved_value) or saved_value < 0
                or type(option_cost) not in (int, float) or not isfinite(option_cost) or option_cost < 0):
            return result(False, "ev", "missing or invalid value/option-cost estimate")
        threshold = (option_cost / (100. + saved_value + option_cost) if free_left
                     else 150. / (250. + saved_value) + (.15 if paid_false else 0.))
        return result(posterior.probability > threshold, "ev", "calibrated expected-value test", threshold)
