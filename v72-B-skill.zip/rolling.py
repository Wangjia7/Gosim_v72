"""Public geometry and bounded, advisory request-group planning. No solver dependency."""
import math
import os
import time
from datetime import timedelta
from skymath import SIDEREAL_DEG_PER_SECOND, local_sidereal_deg, parse_utc, wrap180

DESI_HA_WIDTH = float(os.environ.get('V6_DESI_HA_WIDTH_DEG', '30'))
DESI_HA_FLOOR = float(os.environ.get('V6_DESI_HA_FLOOR', '.75'))
GROUP_BOOST = float(os.environ.get('V6_GROUP_BOOST', '1.25'))
GROUP_HORIZON = float(os.environ.get('V6_GROUP_HORIZON_DAYS', '7'))
GROUP_CPU_FAST = float(os.environ.get('V6_GROUP_CPU_FAST', '.02'))
GROUP_CPU_FULL = float(os.environ.get('V6_GROUP_CPU_FULL', '.05'))
FIXED_LEVEL = int(os.environ.get('V5_FIXED_LEVEL', os.environ.get('PRO_FIXED_LEVEL', '-1')))
DL_REQ = os.environ.get('V6_DL_REQ', '0') == '1'
if (not all(math.isfinite(v) for v in (DESI_HA_WIDTH, DESI_HA_FLOOR, GROUP_BOOST,
                                     GROUP_HORIZON, GROUP_CPU_FAST, GROUP_CPU_FULL))
        or DESI_HA_WIDTH <= 0 or not 0 <= DESI_HA_FLOOR <= 1 or GROUP_BOOST < 1
        or GROUP_HORIZON <= 0 or not 0 < GROUP_CPU_FAST <= GROUP_CPU_FULL):
    raise ValueError('invalid v6.1 HA or request-group tuning parameters')


def _request_setting(name, default, low, high, integer=False):
    raw=os.environ.get('V7_REQ_'+name,str(default))
    value=int(raw) if integer else float(raw)
    if not math.isfinite(value) or not low<=value<=high:
        raise ValueError('invalid V7_REQ_'+name)
    return value

REQ_GROUPS=_request_setting('GROUPS',8,1,64,True)
REQ_TARGETS=_request_setting('TARGETS',48,1,512,True)
REQ_TIMES=_request_setting('TIMES',256,1,4096,True)
REQ_SAMPLES=_request_setting('SAMPLES',24,2,512,True)
REQ_ANCHORS=_request_setting('ANCHORS',8,1,128,True)
REQ_CPU_FAST=_request_setting('CPU_FAST',.02,.0001,1.)
REQ_CPU_FULL=_request_setting('CPU_FULL',.05,.0001,2.)
REQ_CPU_SHARE=_request_setting('CPU_SHARE',.02,0.,.02)
REQ_LATE_SECONDS=_request_setting('LATE_SECONDS',60.,0.,300.)
REQ_REPLAN_SECONDS=_request_setting('REPLAN_SECONDS',300.,60.,3600.)
if REQ_CPU_FAST>REQ_CPU_FULL: raise ValueError('request CPU fast limit exceeds full limit')

class _RequestBudgetExpired(Exception):
    pass


def design_weight(delta):
    return max(DESI_HA_FLOOR, math.exp(-.5*(delta/DESI_HA_WIDTH)**2))


def start_windows(ra, hmax, start, end, lon, duration):
    """All start intervals for a full exposure above the altitude cut, including RA wrap."""
    span = (end-start).total_seconds()
    if duration <= 0 or span < duration or hmax <= 0:
        return []
    if hmax >= 180:
        return [(start, end-timedelta(seconds=duration))]
    ha = wrap180(local_sidereal_deg(start, lon)-ra)
    stop = ha + span*SIDEREAL_DEG_PER_SECOND
    out = []
    for cycle in range(math.ceil((ha-hmax)/360), math.floor((stop+hmax)/360)+1):
        a = max(0., (360*cycle-hmax-ha)/SIDEREAL_DEG_PER_SECOND)
        b = min(span, (360*cycle+hmax-ha)/SIDEREAL_DEG_PER_SECOND)-duration
        if b >= a:
            out.append((start+timedelta(seconds=a), start+timedelta(seconds=b)))
    return out


def goal_gain(science, required, request, science_priority, common):
    """Long-term preference prices science; task obligations keep their own reward."""
    return (science*science_priority+required+request)*common


class RequestPlan:
    # ponytail: enumerate <=8 groups, greedy target insertion; CP-SAT only if measured misses justify it.
    def __init__(self, planner):
        self.p = planner
        self.cache_key = None
        self.focus = set()
        self.diagnostics = {'replans':0, 'nodes':0, 'selected':[], 'advisory':True}

    def update(self, requests, now):
        p = self.p
        if DL_REQ:
            requests = [r for r in requests if float(r.get('completion_reward', 0)) > 0
                        and parse_utc(r['deadline_utc']) > now]
        signature = tuple((r.get('request_id'), r['deadline_utc'], r['minimum_completed'],
                           r.get('remaining_count'), r['completion_factor_threshold'], r['completion_reward'],
                           tuple(r['target_ids']), tuple(r.get('completed_target_ids',[]))) for r in requests)
        key = (int(now.timestamp()//3600), signature, tuple(sorted(p.notices)),
               p.weather.revision if p.weather is not None else 0)
        if key == self.cache_key:
            return self.focus
        self.cache_key = key
        started = time.process_time()
        cpu_limit = GROUP_CPU_FAST if getattr(p,'fast_level',0) >= 2 else GROUP_CPU_FULL
        horizon = min(p.survey_end, now+timedelta(days=GROUP_HORIZON))
        windows = {}
        groups = []
        examined = 0
        for r in requests:
            remaining = int(r.get('remaining_count', r['minimum_completed']))
            deadline = min(parse_utc(r['deadline_utc']), horizon)
            if remaining <= 0 or deadline <= now:
                continue
            jobs = []
            completed = set(r.get('completed_target_ids',[]))
            for tid in dict.fromkeys(r['target_ids']):
                if (examined >= (200 if FIXED_LEVEL >= 2 else 500)) if FIXED_LEVEL >= 0 else (time.process_time()-started >= cpu_limit):
                    break
                examined += 1
                i = p.index_of.get(tid)
                if i is None or tid in completed or p.hmax[i] <= 0:
                    continue
                # Advisory cost uses public transit geometry and learned sky scale.
                # It is not a proof of completion in future weather or of fibre feasibility.
                model = p.ideal_model[i]*max(.05,p.prior_scale)
                need = math.ceil(float(r['completion_factor_threshold'])*p.f0t0/(max(1e-9,p.flux[i]*model)))
                duration = max(p.min_exposure,need)
                if duration > p.max_exposure:
                    continue
                wkey = (i,duration,deadline)
                if wkey not in windows:
                    windows[wkey] = [window for start,end in p.nights if end>now and start<deadline
                        for window in start_windows(p.ra[i],p.hmax[i],max(now,start),min(deadline,end),p.lon,duration)]
                if windows[wkey]:
                    jobs.append((i,duration,windows[wkey]))
            if len(jobs) >= remaining:
                groups.append((deadline, str(r.get('request_id','')), float(r['completion_reward']), remaining, jobs))
        # Keep deadline-near groups first; truncation changes advice, never removes baseline rewards.
        groups.sort(key=lambda g:(g[0],-g[2],g[1]))
        truncated = max(0,len(groups)-8)
        groups = groups[:8]
        best = (0.,0.,(),set())
        nodes = 0
        for mask in range(1,1<<len(groups)):
            if FIXED_LEVEL < 0 and time.process_time()-started >= cpu_limit:
                break
            nodes += 1
            cursor = now
            chosen = set()
            reward = 0.
            ids = []
            valid = True
            for k,(_,rid,value,remaining,jobs) in enumerate(groups):
                if not mask & (1<<k):
                    continue
                used = set()
                for _ in range(remaining):
                    if FIXED_LEVEL < 0 and time.process_time()-started >= cpu_limit:
                        valid = False
                        break
                    options = []
                    for i,duration,ws in jobs:
                        if i in used:
                            continue
                        for a,b in ws:
                            t = max(cursor,a)
                            if t <= b:
                                options.append((t+timedelta(seconds=duration),i))
                                break
                    if not options:
                        valid = False
                        break
                    cursor,i = min(options)
                    used.add(i)
                if not valid:
                    break
                chosen.update(used)
                ids.append(rid)
                reward += value
            if valid:
                candidate = (reward,-(cursor-now).total_seconds(),tuple(ids),chosen)
                if candidate[:3] > best[:3]:
                    best = candidate
        self.focus = best[3]
        cpu = time.process_time()-started
        self.diagnostics = {'replans':self.diagnostics['replans']+1,'nodes':nodes,
                            'selected':list(best[2]),'focus_targets':len(self.focus),
                            'truncated_groups':truncated,'advisory':True,'cpu_seconds':cpu,
                            'budget_limited':cpu>=cpu_limit,'cpu_limit':cpu_limit,
                            'horizon_days':GROUP_HORIZON,'focus_boost':GROUP_BOOST}
        return self.focus

class ReservedRequestPlan:
    """Bounded value-first reservation planner using executable fibre clusters.

    Success factors are throughput forecasts, not completion probabilities. Failed
    reservations are discarded as a group; real request receipts remain authoritative.
    """
    def __init__(self, planner):
        self.p = planner
        self.cache_key = None
        self.focus = set()
        self.reservations = []
        self.diagnostics = {'replans': 0, 'advisory': False}
        self.cpu_spent=0.
        self.overrun_seconds=0.
        self._deadline=float('inf')
        self.active=False
        self.cache_until=None
        self.budget_exits=0

    def credit(self):
        return max(0.,REQ_CPU_SHARE*max(0.,self.p.request_base_cpu)-self.cpu_spent)

    def _check(self):
        if time.process_time()>=self._deadline: raise _RequestBudgetExpired()

    def _metered(self, function, fallback):
        allowance=min(self.credit(),REQ_CPU_FAST if self.p.fast_level>=2 else REQ_CPU_FULL)
        if allowance<=0:
            self.active=False
            return fallback
        started=time.process_time()
        self._deadline=started+allowance
        self._allowance=allowance
        try:
            result=function()
            self._check()
            return result
        except _RequestBudgetExpired:
            self.active=False
            self.cache_key=None
            self.budget_exits+=1
            return fallback
        finally:
            elapsed=max(0.,time.process_time()-started)
            self.cpu_spent+=elapsed
            self.overrun_seconds+=max(0.,elapsed-allowance)
            self._deadline=float('inf')
            self.diagnostics.update(cpu_spent=self.cpu_spent,credit_seconds=self.credit(),
                overrun_seconds=self.overrun_seconds,budget_exits=self.budget_exits,
                cpu_share_limit=REQ_CPU_SHARE,cooperative_budget=True)

    def _live_request(self,reservation,now):
        for request in self.p.requests:
            if str(request.get('request_id',''))!=reservation['request_id']: continue
            if float(request.get('completion_reward',0))<=0 or parse_utc(request['deadline_utc'])<=now: return None
            if int(request.get('remaining_count',request['minimum_completed']))<=0: return None
            return request
        return None

    def _state(self):
        p = self.p
        dl = p.dutylog
        quant=lambda x: None if x is None else round(float(x)/.02)
        return (quant(p.scale), quant(p.prior_scale), quant(p.band_level), quant(p.request_fault_factor),
                p.request_fault_revision, tuple(sorted(p.notices)), p.bad_forecast,
                tuple(sorted(p.extra_avoid)), tuple(p.offset), tuple(p.box),
                p.weather.revision if p.weather else 0,
                dl.version if dl else 0, tuple(dl.flat_windows) if dl else (),
                dl.last_repair if dl else None,
                p.operations.revision if p.operations is not None else None)

    def update(self, requests, now):
        self.p.requests=requests
        if not requests:
            self.focus=set();self.reservations=[];self.active=False
            return self.focus
        if self.cache_key is None and self.credit() < (REQ_CPU_FAST if self.p.fast_level>=2 else REQ_CPU_FULL):
            self.active=False
            return set()
        return self._metered(lambda:self._update(requests,now),set())

    def _update(self, requests, now):
        self._check()
        self.active=True
        p = self.p
        good = [r for r in requests if float(r.get('completion_reward', 0)) > 0
                and int(r.get('remaining_count', r['minimum_completed'])) > 0
                and parse_utc(r['deadline_utc']) > now]
        # Sort before any budget truncation: input order cannot starve a valuable group.
        good.sort(key=lambda r: (-float(r['completion_reward']) / max(1,int(r.get('remaining_count',r['minimum_completed']))),
                                -float(r['completion_reward']), r['deadline_utc'], str(r.get('request_id',''))))
        signature = tuple((str(r.get('request_id','')),r['deadline_utc'],r['completion_reward'],
                           r.get('remaining_count',r['minimum_completed']),r['completion_factor_threshold'],
                           tuple(sorted(r['target_ids'])),tuple(sorted(r.get('completed_target_ids',[])))) for r in good)
        key = (signature,self._state())
        valid=all(r['start']+timedelta(seconds=REQ_LATE_SECONDS)>=now and r['end']>now
                  and self._live_request(r,now) is not None for r in self.reservations)
        if key == self.cache_key and valid and (self.reservations or (self.cache_until and now<self.cache_until)):
            return self.focus
        # A changed cache needs a whole tier allowance, not repeated tiny retries.
        if self._allowance < (REQ_CPU_FAST if p.fast_level>=2 else REQ_CPU_FULL):
            self.cache_key=None
            self.active=False
            return set()
        self.cache_key = key
        self.cache_until=now+timedelta(seconds=REQ_REPLAN_SECONDS)
        self.reservations = []
        weather = p.weather.predict(now) if p.weather is not None else None
        horizon = min(p.survey_end, now+timedelta(days=GROUP_HORIZON))
        examined = 0
        selected = []
        for request in good[:REQ_GROUPS]:
            self._check()
            remaining = int(request.get('remaining_count',request['minimum_completed']))
            threshold = float(request['completion_factor_threshold'])
            complete = set(request.get('completed_target_ids',[]))
            targets = [p.index_of[tid] for tid in set(request['target_ids'])-complete if tid in p.index_of]
            targets.sort(key=lambda i: (-p.flux[i],-p.weight[i],p.ids[i]))
            targets = targets[:REQ_TARGETS]
            deadline = min(parse_utc(request['deadline_utc']),horizon)
            # Reuse already-reserved hits shared by overlapping requests, without another exposure.
            shared = {i for r in self.reservations if r['end'] <= deadline
                      for i,factor in r['factors'].items() if i in targets and factor >= threshold}
            pending = set(targets)-shared
            need = max(0,remaining-len(shared))
            trial = []
            cursor = now
            while need and pending and examined < REQ_TIMES:
                best = None
                for ni,t,stop in self.candidate_times(cursor,deadline,sorted(pending),self.reservations+trial):
                    self._check()
                    if examined >= REQ_TIMES: break
                    examined += 1
                    forecast = weather[ni][:2] if weather is not None else (1.,p.prior_scale)
                    candidate = self.cluster(t,stop,sorted(pending),threshold,forecast,ni)
                    if candidate and not any(candidate['start']<r['end'] and r['start']<candidate['end']
                                             for r in self.reservations+trial):
                        credited = min(need,len(candidate['factors']))
                        rank=(credited*candidate['opening']/candidate['duration'],credited,-t.timestamp())
                        if best is None or rank > best[0]: best=(rank,candidate)
                if best is None: break
                reservation=best[1]
                reservation.update(request_id=str(request.get('request_id','')),threshold=threshold,
                                   deadline=deadline)
                trial.append(reservation)
                pending.difference_update(reservation['factors'])
                need=max(0,need-len(reservation['factors']))
                cursor=reservation['end']
            if not need:
                self.reservations.extend(trial)
                selected.append(str(request.get('request_id','')))
        self.reservations.sort(key=lambda r:r['start'])
        self.focus={i for r in self.reservations for i in r['factors']}
        self.diagnostics={'replans':self.diagnostics['replans']+1,'advisory':False,'selected':selected,
                          'reservations':len(self.reservations),'focus_targets':len(self.focus),
                          'examined_times':examined,'budget_limited':examined>=REQ_TIMES,'groups_truncated':max(0,len(good)-REQ_GROUPS),
                          'fault_factor':p.request_fault_factor,'fault_revision':p.request_fault_revision,
                          'calibration':'throughput forecast; not a completion posterior'}
        return self.focus

    def candidate_times(self, cursor, deadline, targets, occupied, limit=None):
        """Spread a deterministic budget across visible windows of ALL available nights."""
        p=self.p
        limit=REQ_SAMPLES if limit is None else limit
        boundaries=[r['end'] for r in occupied]
        if p.dutylog is not None: boundaries.extend(b for a,b in p.dutylog.flat_windows)
        if p.operations is not None: boundaries.extend(b for a,b in getattr(p.operations,'windows',()))
        nights=[]
        for ni,(start,end) in enumerate(p.nights):
            self._check()
            start,stop=max(cursor,start),min(end,deadline)
            if (stop-start).total_seconds()<p.min_exposure: continue
            moments=set()
            for i in targets:
                self._check()
                for a,b in start_windows(p.ra[i],p.hmax[i],start,stop,p.lon,p.min_exposure):
                    first=a+timedelta(microseconds=1000000-a.microsecond) if a.microsecond else a
                    last=b.replace(microsecond=0)
                    if first<=last:
                        moments.update((first,last,(first+(last-first)/2).replace(microsecond=0)))
                    moments.update(t for t in boundaries if a<=t<=b)
            moments=sorted(t for t in moments if not any(r['start']<=t<r['end'] for r in occupied))
            if moments: nights.append((ni,stop,moments))
        if len(nights)>limit:
            nights=[nights[round(k*(len(nights)-1)/(limit-1))] for k in range(limit)]
        out=[]
        for k,(ni,stop,moments) in enumerate(nights):
            count=min(len(moments),limit//len(nights)+int(k<limit%len(nights)))
            indices=[0] if count==1 else [round(j*(len(moments)-1)/(count-1)) for j in range(count)]
            out.extend((ni,moments[j],stop) for j in indices)
        return sorted(out,key=lambda item:(item[1],item[0]))

    def cluster(self, start, stop, targets, threshold, forecast, night_index):
        from skymath import Moon, normalized_airmass, radec_to_altaz, shift_altaz, tangent_offsets
        p=self.p
        opening,weather_q=forecast
        if opening <= 0 or p.request_fault_factor <= 0: return None
        max_t=int(min(p.max_exposure,(stop-start).total_seconds()))
        if p.dutylog is not None: max_t=int(p.dutylog.clip_exposure(start,max_t))
        if p.operations is not None: max_t=int(p.operations.clip_exposure(start,max_t))
        if max_t < p.min_exposure: return None
        lst=local_sidereal_deg(start,p.lon)
        positions={i:radec_to_altaz(p.ra[i],p.dec[i],lst,p.lat) for i in targets}
        # Keep the observed current loss as well as explicit known-fault discount.
        # min avoids multiplying two measurements of the same loss twice.
        scale=max(0.,min(p.scale,float(weather_q)*p.request_fault_factor))
        if p.bad_forecast: scale*=.7
        if scale<=0: return None
        band_scale=max(.01,float(weather_q))
        moon=Moon(start+timedelta(seconds=max_t/2),lst+max_t*.5*SIDEREAL_DEG_PER_SECOND,p.lat,p.lunar_model)
        models={}
        directional={}
        for i,(alt,az) in positions.items():
            self._check()
            if alt<p.min_alt or p._direction_factor(alt,az)<=0: continue
            if p.dutylog is not None and p.dutylog.has_terrain and alt<p.dutylog.horizon(az): continue
            model=moon.lunar_factor(p.ra[i],p.dec[i])/(p.q0*normalized_airmass(max(1.,alt))**p.airmass_exponent)
            models[i]=model
            directional[i]=min(1.,p._direction_factor(alt,az))
        best=None
        geometry={}
        moons={}
        programs=sorted(p.multipliers)
        for anchor in sorted(models,key=lambda i:(-p.flux[i],p.ids[i]))[:REQ_ANCHORS]:
            self._check()
            for fiber in p.central4:
                self._check()
                dn,de=p.grid.fiber_center(fiber)
                ca,cz=shift_altaz(*positions[anchor],-dn,-de)
                if not p.min_alt<=ca<=89.: continue
                cells={}
                for i in models:
                    self._check()
                    offset=tangent_offsets(*positions[i],ca,cz)
                    if offset is None: continue
                    fib,margin=p.grid.classify(*offset)
                    if fib is None or margin<.04: continue
                    if p.pointing is not None and p.pointing.p_inside(*offset,fib,ca)<.5: continue
                    cells.setdefault(fib,[]).append(i)
                for program in programs:
                    self._check()
                    options={}
                    for fib,indices in cells.items():
                        self._check()
                        values=[]
                        for i in indices:
                            band=p._band(models[i]*band_scale)
                            mult=p.multipliers[program] if band==program else p.mismatch
                            # Official request completion uses physical factor, independent of program bonus.
                            rate=p.flux[i]*models[i]*scale*directional[i]/p.f0t0
                            need=math.ceil(threshold/max(1e-12,rate))
                            if threshold>1. or need>max_t: continue
                            values.append((max(p.min_exposure,need),i,rate))
                        if values: options[fib]=min(values)
                    for duration in sorted({v[0] for v in options.values()} | {max_t}):
                        self._check()
                        pick={fib:v for fib,v in options.items() if v[0]<=duration}
                        valid={}
                        for fib,(_,i,rate) in pick.items():
                            self._check()
                            if (i,duration) not in geometry:
                                points=[positions[i]]+[radec_to_altaz(p.ra[i],p.dec[i],lst+dt*SIDEREAL_DEG_PER_SECOND,p.lat)
                                                      for dt in (duration*.5,duration)]
                                direction=min(1.,*(p._direction_factor(a,z) for a,z in points))
                                if any(a<p.min_alt or (p.dutylog is not None and p.dutylog.has_terrain and a<p.dutylog.horizon(z))
                                       for a,z in points): direction=0.
                                if duration not in moons:
                                    moons[duration]=Moon(start+timedelta(seconds=duration*.5),
                                                        lst+duration*.5*SIDEREAL_DEG_PER_SECOND,p.lat,p.lunar_model)
                                lunar=moons[duration].lunar_factor(p.ra[i],p.dec[i])
                                sky=[lunar/(p.q0*normalized_airmass(max(1.,a))**p.airmass_exponent) for a,z in points]
                                # Prediction is conservative, but the quality ledger retains pure sky geometry.
                                geometry[i,duration]=(min(sky)*direction,(sky[0]+4*sky[1]+sky[2])/6)
                            conservative,average=geometry[i,duration]
                            factor=min(1.,p.flux[i]*conservative*scale*duration/p.f0t0)
                            if factor+1e-12<threshold: continue
                            valid[fib]=(i,factor)
                        if not valid: continue
                        science=sum(p.weight[i]*factor*(p.multipliers[program] if p._band(geometry[i,duration][1]*band_scale)==program else p.mismatch)
                                    for i,factor in valid.values())
                        rank=(len(valid)*opening/duration,len(valid),science,-duration)
                        if best is None or rank>best[0]:
                            best=(rank,{'start':start,'end':start+timedelta(seconds=duration),'duration':duration,
                                        'pointing':(round(ca,4),round(cz,4)%360),'program':program,
                                        'assignments':{fib:i for fib,(i,_) in valid.items()},
                                        'factors':{i:f for i,f in valid.values()},'opening':opening,'night_index':night_index,
                                        'models':{i:geometry[i,duration][1] for i,f in valid.values()},'positions':positions,'scale':scale,'forecast':forecast})
        return best[1] if best else None

    def has_due(self,now):
        return self.active and any(r['start']<=now<=r['start']+timedelta(seconds=REQ_LATE_SECONDS)
            and r['end']>now and self._live_request(r,now) is not None for r in self.reservations)

    def due(self,now):
        if not self.active: return None
        return self._metered(lambda:self._due(now),None)

    def _due(self,now):
        for old in self.reservations:
            self._check()
            if not old['start']<=now<=old['start']+timedelta(seconds=REQ_LATE_SECONDS): continue
            request=self._live_request(old,now)
            if request is None: continue
            complete=set(request.get('completed_target_ids',[]))
            allowed=set(request['target_ids'])-complete
            targets=[i for i in old['factors'] if self.p.ids[i] in allowed]
            stop=min(old['end'],old['deadline'],parse_utc(request['deadline_utc']))
            forecast=old['forecast']
            if self.p.weather is not None: forecast=self.p.weather.predict(now)[old['night_index']][:2]
            current=self.cluster(now,stop,targets,float(request['completion_factor_threshold']),forecast,old['night_index'])
            if current is not None:
                current.update(request_id=old['request_id'],deadline=old['deadline'],
                               threshold=float(request['completion_factor_threshold']),reservation_start=old['start'])
                return current
        return None

    def consume(self,reservation):
        key=reservation.get('reservation_start',reservation['start'])
        self.reservations=[r for r in self.reservations if not (r['start']==key and r['request_id']==reservation['request_id'])]
        self.cache_until=reservation['end']

    def limit(self,now,seconds):
        if not self.active: return seconds
        return self._metered(lambda:self._limit(now,seconds),seconds)

    def _limit(self,now,seconds):
        future=[]
        for r in self.reservations:
            self._check()
            if r['start']>now and self._live_request(r,now) is not None:
                future.append((r['start']-now).total_seconds())
        return min(seconds,min(future)) if future else seconds
