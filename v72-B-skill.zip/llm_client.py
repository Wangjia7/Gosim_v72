"""ZETA Chat Completions client; all configuration comes from ZETA_* only."""
from __future__ import annotations

import json
import hashlib

import os

API_ASYNC = os.environ.get("V7_API_ASYNC", "0") == "1"
import re
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit
from switches import TIERED, NIGHT_WAIT, VALUES

_JSON_OBJECT = re.compile(r"\{.*\}", re.S)


def provider_config():
    key = os.environ.get('ZETA_API_KEY', '').strip()
    base = os.environ.get('ZETA_BASE_URL', '').strip().rstrip('/')
    model = os.environ.get('ZETA_MODEL', '').strip()
    endpoint = urlsplit(base)
    valid = (endpoint.scheme in ('http', 'https') and endpoint.hostname and
             not endpoint.username and not endpoint.password and not endpoint.query and not endpoint.fragment)
    return (key if valid and model else ''), base, model


def api_key():
    return provider_config()[0]


def load_dotenv(path: str) -> None:
    """Fill missing environment variables from a local .env (for local runs only)."""
    try:
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                name, value = line.split("=", 1)
                name, value = name.strip(), value.strip().strip('"').strip("'")
                if name and value and not os.environ.get(name):
                    os.environ[name] = value
    except OSError:
        pass


class Call:
    """One background chat completion."""

    def __init__(self, client: "LLMClient", tag: str, system: str, user: dict, timeout: float):
        self.tag = tag
        self.input_hash = hashlib.sha256(json.dumps([system, user], sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        self.timeout = timeout
        self.wait_limit = getattr(client, "skill_wait_limit" if tag.startswith('dutylog_') else "night_wait_limit", NIGHT_WAIT)
        self.answer = None
        self.error = None
        self.seconds = 0.0
        self._done = threading.Event()
        self._thread = threading.Thread(target=self._run, args=(client, system, user, timeout), daemon=True)
        self._thread.start()

    def _run(self, client, system, user, timeout) -> None:
        started = time.monotonic()
        for attempt in range(client.max_retries):
            remaining = timeout - (time.monotonic() - started)
            if remaining <= 0:
                break
            try:
                self.answer = client._request(system, user, remaining, self.tag) if TIERED else client._request(system, user, remaining)
                self.error = None
                break
            except (urllib.error.URLError, OSError, ValueError, KeyError, IndexError, TypeError) as exc:
                self.error = "TimeoutError" if isinstance(exc, TimeoutError) or "timed out" in str(exc).lower() else type(exc).__name__
                if time.monotonic() - started > timeout:
                    break
                time.sleep(min(1.0 + attempt, max(0.0, timeout - (time.monotonic() - started))))
        self.seconds = time.monotonic() - started
        self._done.set()

    def done(self) -> bool:
        return self._done.is_set()

    def wait(self, seconds: float) -> bool:
        return self._done.wait(max(0.0, seconds))


class LLMClient:
    def __init__(self, log=lambda text: None, call_timeout: float = 90.0, max_calls: int = 1500,
                 max_retries: int = 3, max_in_flight: int = 4):
        self.log = log
        self.provider = 'zeta'
        self.key, self.base_url, self.model = provider_config()
        if not self.key:
            self.log('llm: missing/invalid ZETA_API_KEY / ZETA_BASE_URL / ZETA_MODEL; rules decide')
        self.call_timeout = min(call_timeout, 20.0) if API_ASYNC else call_timeout
        self.max_calls = min(max_calls, 400) if API_ASYNC else max_calls
        self.max_retries = max_retries
        self.max_in_flight = max_in_flight
        self.calls: list[Call] = []
        self.ok = 0
        self.failed = 0
        self.sim_hours = 0.0
        self.timeout_streak = 0
        self.circuit_until = -float("inf")
        self.allow_submit = True
        self.night_wait_limit = NIGHT_WAIT
        self.night_slow = False

    def set_sim_time(self, hours):
        self.sim_hours = float(hours)
        # Collect abandoned handles too: they still count toward timeout and call limits.
        for call in self.calls:
            if call.done():
                self.collect(call)


    def request_payload(self, system, user, tag=None):
        requested = VALUES['V7_MODEL_EFFORT']
        effort = 'low' if requested == 'auto' else requested
        return {"model": self.model,
                "messages": [{"role": "system", "content": system},
                             {"role": "user", "content": json.dumps(user, separators=(',', ':'))}],
                "max_completion_tokens": 4000, "reasoning_effort": effort}

    def _request(self, system: str, user: dict, timeout: float, tag=None) -> dict:
        payload = self.request_payload(system, user, tag)
        if TIERED:
            self.log('v7 llm request ' + json.dumps({'tag': tag, 'provider': 'zeta',
                'model': self.model, 'reasoning_effort': payload['reasoning_effort'],
                'max_completion_tokens': payload['max_completion_tokens']}, separators=(',', ':')))
        base = self.base_url if self.base_url.endswith('/v1') else self.base_url + '/v1'
        request = urllib.request.Request(base + '/chat/completions',
            data=json.dumps(payload).encode('utf-8'), method='POST',
            headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + self.key})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode('utf-8'))
        text = data['choices'][0]['message']['content'] or ''
        match = _JSON_OBJECT.search(text)
        if not match:
            raise ValueError('no JSON object in the reply')
        parsed = json.loads(match.group(0))
        if not isinstance(parsed, dict):
            raise ValueError('reply is not a JSON object')
        return parsed

    def in_flight(self) -> int:
        return sum(1 for call in self.calls if not call.done())

    def submit(self, tag: str, system: str, user: dict, wallclock_left: float):
        """Start a call in the background; None when the run's limits say no."""
        if not self.key:
            return None
        if API_ASYNC:
            self.set_sim_time(self.sim_hours)
            if not self.allow_submit or self.sim_hours < self.circuit_until:
                return None
        timeout = min(self.call_timeout, wallclock_left - 30.0)
        if len(self.calls) >= self.max_calls or timeout < 5.0 or self.in_flight() >= self.max_in_flight:
            return None
        call = Call(self, tag, system, user, timeout)
        self.calls.append(call)
        return call

    def collect(self, call):
        """The parsed answer of a finished call (None while running or after a failure). Logs once."""
        if call is None or not call.done():
            return None
        if not getattr(call, "_logged", False):
            call._logged = True
            if TIERED and call.tag in {'night_plan', 'dutylog_extract', 'dutylog_repair'} and (call.answer is not None or
                    call.error in {'TimeoutError', 'timeout'} or call.seconds >= call.timeout):
                if call.seconds > getattr(call, 'wait_limit', NIGHT_WAIT):
                    # Stay at none for the remainder of this run once low exceeded its useful wait.
                    self.night_slow = True
            if API_ASYNC:
                timed_out = call.answer is None and (call.error in {"TimeoutError", "timeout"} or
                                                    call.seconds >= call.timeout)
                self.timeout_streak = self.timeout_streak + 1 if timed_out else 0
                if self.timeout_streak >= 3:
                    self.circuit_until = self.sim_hours + 6.0
                    self.timeout_streak = 0
                    self.log(f"v7 llm circuit open until simulation hour {self.circuit_until:.3f}")
                self.log("v7 llm response " + json.dumps({"tag": call.tag, "input_sha256": call.input_hash,
                         "answer": call.answer, "error": call.error}, separators=(",", ":")))
            if call.answer is not None:
                self.ok += 1
                self.log(f'llm: {call.tag} accepted transport response in {call.seconds:.2f}s')
            else:
                self.failed += 1
                self.log(f"llm: {call.tag} failed ({call.error}); rules decide")   # never log the key
        return call.answer
