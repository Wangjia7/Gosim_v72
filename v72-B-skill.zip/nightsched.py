"""Night plan + greedy (v7.1): plan the whole night at dusk, let the step-by-step greedy execute it.

The planner's greedy picks the best field for the current moment only. Over a night that wastes good moments:
a field taken at high airmass now may have its transit later, and a field that is only up early can lose its
slot to one that could have waited. The night plan fixes the order, the greedy keeps the details.

Plan (at the first decision of a night, after a gap longer than an exposure, and every REPLAN_HOURS):
  slots     the rest of the night in SLOT-second slots (LST and Moon per slot)
  fields    the most valuable targets in their season window tonight seed fields (open required targets carry
            their bonus x deadline priority, so they come first); a field's members are the best targets
            within half a field of view of its seed, at most n_fibres, each target in one field only
  value     V(f, k, n) = sum over members of
                weight * max(0, reach * m(band) - best so far) * season price
              + REQUIRED_BONUS * deadline priority * ramp(reach / g_req)        (open required targets)
            for an exposure of n slots (n <= 4) starting at slot k, reach = min(1, flux * n*SLOT * model * quality / f0T0),
            model = Moon factor / (q0 * airmass ** exponent) averaged over the slots (0 if a member sets)
  greedy    lazy global greedy over (field, k, n) by V - lambda * n*SLOT: the best pair anywhere in the night
            first, so each field gets its best free moment; slots are never shared
Sky map (V7_SKYMAP_NS=1 with an active V7_SKYMAP): model x the sky map's directional factor per slot, with the
latest bulletin's directional notices held for the rest of the night; a change of those notices replans.
Execution: plan() keeps its own search and multiplies a target's gain by
  1 + BOOST  if its field is planned for the current slot (and adds that field's seed as an anchor),
  DEFER      if its field is planned for a later slot tonight (not for deadline-tight required targets).
Public catalogue, ephemeris, score formula and own results only; standard library only.
"""
from __future__ import annotations

import heapq
import math
import os
import time
from datetime import timedelta

import skymap
from skymath import Moon, local_sidereal_deg


def _env(name, default):
    return type(default)(os.environ.get(f"V7_{name}", default))


ENABLED = _env("NS", 0)
SLOT = _env("NS_SLOT", 1800)                 # seconds per plan slot
BOOST = _env("NS_BOOST", 0.5)                # gain x (1 + BOOST) for the field planned now
DEFER = _env("NS_DEFER", 0.7)                # gain x DEFER for a field planned later tonight
REPLAN_HOURS = _env("NS_REPLAN_H", 4.0)
MAX_FIELDS = _env("NS_FIELDS", 160)          # fields per plan at full speed (fewer at the faster levels)
GAP_SLOTS = 1.0                              # replan after a gap longer than the longest exposure plus a slot
AM_A, AM_B, AM_C = 0.50572, 96.07995, -1.6364   # normalized_airmass (skymath), inlined
AM_NORM = 1.0 / (1.0 + AM_A * AM_B ** AM_C)


class NightScheduler:
    def __init__(self, planner, required_bonus, p_lo, p_hi):
        self.p = planner
        self.ramp = (required_bonus, p_lo, p_hi)
        self.night = -1
        self.t0 = None                       # start of slot 0
        self.planned_at = None
        self.last_call = None
        self.entries = []                    # (start slot, n slots, field id)
        self.fields = []                     # field id -> member list (seed first)
        self.slot_of = {}                    # target -> (start slot, end slot) of its planned field
        self.mult_cache = (None, {})
        self.cpu = 0.0
        self.plans = 0
        self.xyz = {}
        self.sectors = None                  # directional notices the plan was made under (sky map)

    # --- plan -------------------------------------------------------------------------------------------
    def update(self, now, horizon, night_index, hours):
        p = self.p
        stale = (night_index != self.night or self.planned_at is None
                 or (now - self.planned_at).total_seconds() >= REPLAN_HOURS * 3600.0
                 or (self.last_call is not None and (now - self.last_call).total_seconds() > p.max_exposure + GAP_SLOTS * SLOT))
        self.last_call = now
        sectors = p.sky_sectors if skymap.NS and skymap.ACTIVE and p.skymap is not None else []
        stale = stale or sectors != self.sectors
        if stale:
            self.sectors = sectors
            t = time.process_time()
            self._plan(now, horizon, night_index, hours)
            self.cpu += time.process_time() - t
            self.plans += 1

    def _unit(self, i):
        v = self.xyz.get(i)
        if v is None:
            p = self.p
            r = math.radians(p.ra[i])
            v = self.xyz[i] = (p.cos_dec[i] * math.cos(r), p.cos_dec[i] * math.sin(r), p.sin_dec[i])
        return v

    def _plan(self, now, horizon, night_index, hours):
        p = self.p
        self.night, self.t0, self.planned_at = night_index, now, now
        self.entries, self.fields, self.slot_of, self.mult_cache = [], [], {}, (None, {})
        n_slots = int((horizon - now).total_seconds() // SLOT)
        if n_slots <= 0:
            return
        # per slot: LST terms and the Moon (unit vector and penalty amplitude of the public lunar model)
        lm = p.lunar_model
        decay = float(lm["angular_decay_scale_deg"])
        slots = []
        for k in range(n_slots):
            moment = now + timedelta(seconds=(k + 0.5) * SLOT)
            lst = math.radians(local_sidereal_deg(moment, p.lon))
            moon = Moon(moment, math.degrees(lst), p.lat, lm)
            amp = 0.0
            mv = (0.0, 0.0, 1.0)
            if moon.alt > 0.0:
                amp = (float(lm["maximum_penalty"]) * moon.illumination
                       * math.sin(math.radians(moon.alt)) ** float(lm["altitude_exponent"]))
                mr, md = math.radians(moon.ra), math.radians(moon.dec)
                mv = (math.cos(md) * math.cos(mr), math.cos(md) * math.sin(mr), math.sin(md))
            slots.append((math.cos(lst), math.sin(lst), amp, mv))
        lim = p.sin_alt_limit
        q0, ex = p.q0, p.airmass_exponent
        model = {}
        sectors, smap = self.sectors, p.skymap
        slat, clat = p.sin_lat, p.cos_lat

        def sky(i):
            """Sky model per slot (0 = below the limit), or None when never up tonight."""
            row = model.get(i, False)
            if row is False:
                a, b, c = p.alt_a[i], p.alt_b[i], p.alt_c[i]
                x, y, z = self._unit(i)
                row = []
                up = False
                for cl, sl, amp, (mx, my, mz) in slots:
                    s = a + b * cl + c * sl
                    if s < lim:
                        row.append(0.0)
                        continue
                    up = True
                    zen = 90.0 - math.degrees(math.asin(s if s < 1.0 else 1.0))
                    airmass = AM_NORM * (s + AM_A * (AM_B - zen) ** AM_C)   # 1 / normalized airmass
                    lunar = 1.0
                    if amp > 0.0:
                        d = x * mx + y * my + z * mz
                        sep = math.degrees(math.acos(d if -1.0 < d < 1.0 else (1.0 if d >= 1.0 else -1.0)))
                        lunar = max(0.0, 1.0 - amp * math.exp(-sep / decay))
                    value = lunar * airmass ** ex / q0
                    if sectors:
                        # azimuth from north through east: hour angle H, cos(dec) sin H = sl x - cl y
                        sh, ch = sl * x - cl * y, cl * x + sl * y
                        az = math.degrees(math.atan2(-sh, z * clat - ch * slat)) % 360.0
                        value *= smap.factor(math.degrees(math.asin(s if s < 1.0 else 1.0)), az, sectors, explore=False)
                    row.append(value)
                row = row if up else None
                model[i] = row
            return row

        # fields around the most valuable targets up tonight
        vc = p.vcache
        cap = max(20, MAX_FIELDS >> min(p.fast_level, 3))
        pool = [i for i in p.active if vc[i] > 0.0 and p.first_night[i] <= night_index <= p.last_night[i]]
        taken = set()
        radius = p.grid.fov / 2.0
        for i in heapq.nlargest(cap * 4, pool, key=vc.__getitem__):
            if i in taken or sky(i) is None:
                continue
            near = [j for j in p.neighbours(p.ra[i], p.dec[i], radius)
                    if j not in taken and j != i and vc[j] > 0.0 and p.first_night[j] <= night_index <= p.last_night[j]]
            near = heapq.nlargest(p.grid.n - 1, near, key=vc.__getitem__)
            members = [i] + [j for j in near if sky(j) is not None]
            taken.update(members)
            self.fields.append(members)
            if len(self.fields) >= cap:
                break
        # value of each field per start slot and length
        q = (p.good_scale or p.scale or p.prior_scale) * 0.97
        band_scale = p.calibrated_band_scale(hours)
        lam = p.lambda_frac * p.rate_ema
        lengths = [n for n in (1, 2, 3, 4) if p.min_exposure <= n * SLOT <= p.max_exposure] or [1]
        g_req, dl = p.g_req, p.deadline
        req_bonus, p_lo, p_hi = self.ramp      # the step search's ramp
        bands = [(float(p.bands["DARK"]), p.multipliers["DARK"]), (float(p.bands["BRIGHT"]), p.multipliers["BRIGHT"])]
        backup = p.multipliers["BACKUP"]
        table = []                           # field -> {(k, n): net}
        heap = []
        for f, members in enumerate(self.fields):
            totals = {(k, n): 0.0 for n in lengths for k in range(n_slots - n + 1)}
            for i in members:
                row = model[i]
                w, cur, sm = p.weight[i], p.cur[i], p.smult[i]
                a0 = p.flux[i] * SLOT * q / p.f0t0
                bonus = (req_bonus * (dl.priority(i) if dl is not None else 1.0)
                         if p.required[i] and p.factor[i] < g_req else 0.0)
                for n in lengths:
                    for k in range(n_slots - n + 1):
                        if n == 1:
                            m = row[k]
                            if m <= 0.0:
                                continue
                        else:
                            ms = row[k:k + n]
                            if min(ms) <= 0.0:
                                continue
                            m = sum(ms) / n
                        raw = a0 * n * m
                        qb = m * band_scale
                        mult = bands[0][1] if qb >= bands[0][0] else bands[1][1] if qb >= bands[1][0] else backup
                        v = w * ((raw if raw < 1.0 else 1.0) * mult - cur)
                        v = v * sm if v > 0.0 else 0.0
                        if bonus:
                            r = (raw / g_req - p_lo) / (p_hi - p_lo)
                            v += bonus * (1.0 if r >= 1.0 else r if r > 0.0 else 0.0)
                        totals[(k, n)] += v
            opts = {kn: v - lam * kn[1] * SLOT for kn, v in totals.items() if v > 0.0 and v > lam * kn[1] * SLOT}
            table.append(opts)
            if opts:
                heap.append((-max(opts.values()), f))
        heapq.heapify(heap)
        free = [True] * n_slots
        while heap and any(free):
            neg, f = heapq.heappop(heap)
            best = max(((net, kn) for kn, net in table[f].items() if all(free[kn[0]:kn[0] + kn[1]])), default=None)
            if best is None:
                continue
            if best[0] < -neg - 1e-9:
                heapq.heappush(heap, (-best[0], f))
                continue
            k, n = best[1]
            for s in range(k, k + n):
                free[s] = False
            self.entries.append((k, n, f))
            for i in self.fields[f]:
                self.slot_of[i] = (k, k + n)
        self.entries.sort()
        if night_index % 10 == 0:
            p.log(f"nightsched: night {night_index} slots {n_slots} used {sum(e[1] for e in self.entries)} "
                  f"fields {len(self.entries)}/{len(self.fields)} targets {len(model)} cpu {self.cpu:.1f}s plans {self.plans}")

    # --- execution --------------------------------------------------------------------------------------
    def current_slot(self, now):
        if self.t0 is None:
            return -1
        return int((now - self.t0).total_seconds() // SLOT)

    def multipliers(self, now):
        """target -> gain multiplier for this decision (planned targets only)."""
        k = self.current_slot(now)
        if self.mult_cache[0] == k:
            return self.mult_cache[1]
        dl = self.p.deadline
        out = {}
        for i, (start, end) in self.slot_of.items():
            if start <= k < end:
                out[i] = 1.0 + BOOST
            elif start > k and DEFER < 1.0 and not (dl is not None and dl.slack.get(i, 1e9) <= 0.0):
                out[i] = DEFER
        self.mult_cache = (k, out)
        return out

    def anchor(self, now):
        """Seed target of the field planned for the current slot, or None."""
        k = self.current_slot(now)
        for start, n, f in self.entries:
            if start <= k < start + n:
                return self.fields[f][0]
        return None
