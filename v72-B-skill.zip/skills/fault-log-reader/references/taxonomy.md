# Public event semantics and optical hypotheses

This reference contains generic principles, not empirical calibration from a scenario.

## Event types

- fault / fault_postconfirm: persistent instrument throughput loss, requiring independent data confirmation.
- fault_warning / cooling_hint: tentative hypothesis, never sufficient for a report.
- flat_test: planned calibration window; not a fault.
- downtime: explicit planned observing interruption with public start and end times.
- closure_all: explicit whole-site closure; closure_dir affects only stated directions.
- weather, terrain, quake, power outage and other planned windows are not reportable instrument faults.
- Rumor, cancellation, supersession, another site and self-clearing effects cannot authorize reporting.

## Effect forms

I means near-total loss; II means partial persistent loss. Directional means a direction-dependent change.
Gradual means a time-dependent change; none means no throughput loss; not_fault means another cause;
unknown means evidence does not identify the form. Never infer a numeric loss ratio from component identity.
Use only a ratio explicitly stated in the current public line or measured in the current run.

## Optical reasoning

Guiding and mount failures can misplace images on fibers. Fiber-positioner failures can lose a subset of fibers.
Mirror contamination and corrector problems can degrade throughput. Dome tracking may obstruct some directions.
A closed shutter can block light; cooling issues can alter detector behavior. These are hypotheses, not labels.
Calibration lamps, maintenance and closed-site windows require exclusion rather than instrument reporting.

## Verification

A proposed abrupt change requires measured pre/post exposure evidence. A directional effect requires matched
observations by direction. Gradual decline requires a time series. Always preserve weather and planned-window
alternatives. Models cannot establish a report decision or calculate trusted absolute times.
