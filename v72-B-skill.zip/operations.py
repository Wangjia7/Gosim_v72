"""Public, explicit whole-site downtime and post-repair required-target retrying."""
import re
from datetime import timedelta

from dutylog import DutyLog, _decoded
from skymath import parse_utc
from switches import QA0_MAX_REQUEUES

_KIND = re.compile(r'停机|全站关闭|停止观测|维护停观|全站停电|downtime|site closed|stop observing|power outage', re.I)
_SCOPE = re.compile(r'全站|全台|全天区|停止观测|无法观测|停观|whole.site|entire.site|all.sky|stop observing|unable to observe|site closed', re.I)
_UNSAFE = re.compile(r'传闻|听说|据说|好像|可能|如果|若|别站|他站|其他台|隔壁|另一个|自恢复|自动恢复|不影响|不停机|不关闭|无需停|rumou?r|other site|might|maybe|\bif\b|not closed|[?？]', re.I)
_CANCEL = re.compile(r'取消|撤销|cancelled|canceled|中止', re.I)
_CANCEL_UNSAFE = re.compile(r'传闻|听说|据说|好像|可能|如果|若|别站|他站|其他台|隔壁|不(?:要|能)?取消|未(?:被)?取消|rumou?r|other site|might|maybe|\bif\b|not cancel|[?？]', re.I)
_CHANGE = re.compile(r'更正|推迟|延期|改为|不对|corrected|postponed', re.I)
_ISO = re.compile(r'\d{4}-\d\d-\d\dT\d\d:\d\d(?::\d\d)?(?:Z|[+-]\d\d:\d\d)')
_DATE_CLOCK = re.compile(r'\d{1,2}(?:月|/|-)\d{1,2}日?\s*(?:晚上|夜间)?\s*\d{1,2}[:：]\d\d')


class Operations:
    def __init__(self, utc_offset_hours=0., log=lambda text: None):
        self.decoder = DutyLog(utc_offset_hours)
        self.log = log
        self.events = {}
        self.cancelled = set()
        self.windows = []
        self.seen = set()
        self.revision = 0
        self.revoked_before = {}
        self.revoked_requests = {}
        self.review_needed = False

    def explicit_window(self, text, issued):
        """No inferred duration, vague date, or model-supplied timestamp."""
        try:
            return self._window(text, issued)
        except (ValueError, TypeError, OverflowError):
            return None

    def _window(self, text, issued):
        stamps = _ISO.findall(text)
        if len(stamps) == 2:
            start, end = map(parse_utc, stamps)
        elif stamps:
            return None
        else:
            dated = _DATE_CLOCK.findall(text)
            if len(dated) == 2:
                zone = re.search(r'UTC\s*[+-]?\s*\d*(?:\.\d+)?|东京|Tokyo|工程钟', text, re.I)
                parts = [self.decoder._times(t + (' ' + zone[0] if zone else ''), issued) for t in dated]
                if any(len(p) != 1 for p in parts):
                    return None
                start, end = (p[0][2] for p in parts)
            else:
                times = self.decoder._times(text, issued)
                if len(times) != 2 or not re.fullmatch(r'\s*(?:到|至|[-–—~〜～]|to|until)\s*', text[times[0][1]:times[1][0]], re.I):
                    return None
                start, end = times[0][2], times[1][2]
                if end <= start:
                    end += timedelta(days=1)
        return (start, end) if start < end <= start + timedelta(days=31) else None

    def ingest(self, messages, now, allow_new=True):
        before = dict(self.events)
        for message in messages:
            text = message.get('reason') or message.get('text') or ''
            if not text or not message.get('issued_at_utc'):
                continue
            try:
                issued = parse_utc(message['issued_at_utc'])
            except (ValueError, TypeError):
                continue
            if issued > now:
                continue
            for raw in text.splitlines():
                key = issued, raw
                if key in self.seen:
                    continue
                self.seen.add(key)
                line = _decoded(raw, (issued + self.decoder.offset).day)
                if _CANCEL.search(line) and not _CANCEL_UNSAFE.search(line):
                    self._cancel(line, message.get('request_id'), issued)
                    continue
                if not _KIND.search(line) or not _SCOPE.search(line) or _UNSAFE.search(line):
                    continue
                window = self.explicit_window(line, issued)
                if window is None:
                    continue
                if _CANCEL.search(line) or _CHANGE.search(line):
                    # An ambiguous correction revokes the exact old interval; no new guessed one.
                    self.cancelled.add(window)
                    self.events.pop(window, None)
                elif allow_new and window not in self.cancelled:
                    self.events[window] = {'source': raw, 'issued': issued, 'origin': 'rule',
                                          'kind': 'downtime', 'request_id': message.get('request_id')}
        self._refresh(before)

    def _cancel(self, line, request_id, issued):
        flat = bool(re.search(r'平场|フラット|\bflat\b', line, re.I))
        reference = bool(re.search(r'本次|上述|上条|刚才|previous|that window', line, re.I))
        bare = bool(re.fullmatch(r'\s*(?:取消|撤销|中止|cancelled|canceled)[。.!！\s]*', line, re.I))
        relevant = flat or bool(_KIND.search(line) or _SCOPE.search(line))
        if not (relevant or reference or bare):
            return  # e.g. cancelling an unrelated meeting never changes observing windows
        if request_id is not None:
            self.revoked_requests[request_id] = max(issued, self.revoked_requests.get(request_id, issued))
        kind = 'flat' if flat else 'downtime'
        candidates = [(w, e) for w, e in self.events.items() if w[1] > issued and e['issued'] <= issued
                      and (not relevant or e.get('kind', 'downtime') == kind)]
        explicit = self.explicit_window(line, issued)
        if explicit is not None:
            self.cancelled.add(explicit)
            self.events.pop(explicit, None)
            return
        matching = [(w, e) for w, e in candidates if request_id is not None and e.get('request_id') == request_id]
        if matching:
            candidates = matching
        elif reference and candidates:
            newest = max(e['issued'] for _, e in candidates)
            candidates = [(w, e) for w, e in candidates if e['issued'] == newest]
        all_named = bool(re.search(r'全部|所有|\ball\b', line, re.I)) and relevant
        if len(candidates) == 1 or all_named:
            for window, event in candidates:
                self.cancelled.add(window)
                del self.events[window]
            self.review_needed = False
        elif candidates:
            self.review_needed = True
            self.log('p2 operations: ambiguous cancellation; poll at the next bulletin')
        # Delayed model answers from before an explicit same-topic cancellation cannot reactivate it.
        if relevant:
            self.revoked_before[kind] = max(issued, self.revoked_before.get(kind, issued))

    def accept_skill(self, rows, now):
        """Skill classifies semantics; both boundaries must still match public text."""
        before = dict(self.events)
        for row in rows:
            if row.get('kind') not in ('downtime', 'closure_all', 'flat', 'flat_test') or not row.get('operational'):
                continue
            raw = row.get('source', '')
            try:
                issued = parse_utc(row['issued']) if isinstance(row['issued'], str) else row['issued']
                start = parse_utc(row['start']) if isinstance(row['start'], str) else row['start']
                end = parse_utc(row['end']) if isinstance(row['end'], str) else row['end']
                line = _decoded(raw, (issued + self.decoder.offset).day)
                window = self.explicit_window(line, issued)
            except (KeyError, ValueError, TypeError):
                continue
            if (issued > now or not window or window != (start, end) or window in self.cancelled
                    or _UNSAFE.search(line) or _CANCEL.search(line) or _CHANGE.search(line)):
                continue
            if row['kind'] in ('flat', 'flat_test'):
                if not re.search(r'平场|フラット|\bflat(?:[- ]field)?\b', line, re.I):
                    continue
            elif not _SCOPE.search(line):
                continue
            kind = 'flat' if row['kind'] in ('flat','flat_test') else 'downtime'
            if kind in self.revoked_before and issued <= self.revoked_before[kind]:
                continue
            revoked = self.revoked_requests.get(row.get('request_id'))
            if revoked is not None and issued <= revoked:
                continue
            self.events.setdefault(window, {'source': raw, 'issued': issued, 'origin': 'skill',
                'kind': kind, 'request_id': row.get('request_id'),
                'public_revision': row.get('public_revision'), 'topic_version': row.get('topic_version')})
        self._refresh(before)

    def _refresh(self, before):
        if before == self.events:
            return
        merged = []
        for start, end in sorted(self.events):
            if merged and start <= merged[-1][1]:
                merged[-1] = merged[-1][0], max(end, merged[-1][1])
            else:
                merged.append((start, end))
        self.windows = merged
        self.revision += 1
        self.log(f'p2 operations revision={self.revision} windows={len(merged)}')

    def end_at(self, now):
        return next((end for start, end in self.windows if start <= now < end), None)

    def clip_exposure(self, now, seconds):
        if self.end_at(now) is not None:
            return 0.
        return min([float(seconds)] + [(a - now).total_seconds() for a, _ in self.windows if a > now])

    def open_seconds(self, start, end):
        return max(0., (end - start).total_seconds() - sum(
            max(0., (min(end, b) - max(start, a)).total_seconds()) for a, b in self.windows))

    def overlaps(self, start, end):
        return any(a < end and start < b for a, b in self.windows)


def requeue_required(planner):
    """Remove failure penalties after a confirmed repair; never fabricate scores."""
    retried = []
    if not hasattr(planner, 'qa0_requeues'):
        planner.qa0_requeues = {}
    for i, required in enumerate(planner.required):
        if not required or planner.factor[i] >= getattr(planner, 'g_req', .5) or planner.hmax[i] <= 0:
            continue
        if planner.attempts[i] == 0 and i not in planner.req_calib:
            continue
        if planner.qa0_requeues.get(i, 0) >= QA0_MAX_REQUEUES:
            continue
        planner.qa0_requeues[i] = planner.qa0_requeues.get(i, 0) + 1
        planner.attempts[i] = 0
        planner.req_calib.pop(i, None)
        planner.planned[i] = False
        planner.vdirty.add(i)
        if i not in planner.active:
            planner.active.append(i)
        retried.append(i)
    if retried:
        planner.vcache = None
        planner.long_dirty = True
        if planner.group_plan is not None:
            planner.group_plan.cache_key = None
        planner.log(f'p2 QA0 requeued={len(retried)} after confirmed repair')
    return retried
